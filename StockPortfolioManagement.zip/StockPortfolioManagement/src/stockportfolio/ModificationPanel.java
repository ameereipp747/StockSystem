package stockportfolio;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ModificationPanel extends JPanel {

    private JTextField investorIdField, firstNameField, lastNameField, emailField, phoneField;
    private JButton updateInvestorButton;

    private JTextField companyIdField, companyNameField, industryField, headquartersField, foundedYearField;
    private JButton updateCompanyButton;

    private JTextField stockIdField, tickerField, exchangeField, currentPriceField;
    private JComboBox<CompanyItem> companyComboBox;
    private JButton updateStockButton;

    public ModificationPanel() {
        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Investor", createInvestorPanel());
        tabs.addTab("Company", createCompanyPanel());
        tabs.addTab("Stock", createStockPanel());

        tabs.addChangeListener(e -> loadCompanies());

        add(tabs, BorderLayout.CENTER);
    }

    private JPanel createInvestorPanel() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));

        investorIdField = new JTextField();
        firstNameField = new JTextField();
        lastNameField = new JTextField();
        emailField = new JTextField();
        phoneField = new JTextField();

        JButton searchButton = new JButton("Search");
        updateInvestorButton = new JButton("Update");
        updateInvestorButton.setEnabled(false);

        searchButton.addActionListener(e -> searchInvestor());
        updateInvestorButton.addActionListener(e -> updateInvestor());

        panel.add(new JLabel("Investor ID"));
        panel.add(investorIdField);

        panel.add(new JLabel(""));
        panel.add(searchButton);

        panel.add(new JLabel("First Name"));
        panel.add(firstNameField);

        panel.add(new JLabel("Last Name"));
        panel.add(lastNameField);

        panel.add(new JLabel("Email"));
        panel.add(emailField);

        panel.add(new JLabel("Phone"));
        panel.add(phoneField);

        panel.add(new JLabel(""));
        panel.add(updateInvestorButton);

        return panel;
    }

    private JPanel createCompanyPanel() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));

        companyIdField = new JTextField();
        companyNameField = new JTextField();
        industryField = new JTextField();
        headquartersField = new JTextField();
        foundedYearField = new JTextField();

        JButton searchButton = new JButton("Search");
        updateCompanyButton = new JButton("Update");
        updateCompanyButton.setEnabled(false);

        searchButton.addActionListener(e -> searchCompany());
        updateCompanyButton.addActionListener(e -> updateCompany());

        panel.add(new JLabel("Company ID"));
        panel.add(companyIdField);

        panel.add(new JLabel(""));
        panel.add(searchButton);

        panel.add(new JLabel("Company Name"));
        panel.add(companyNameField);

        panel.add(new JLabel("Industry"));
        panel.add(industryField);

        panel.add(new JLabel("Headquarters"));
        panel.add(headquartersField);

        panel.add(new JLabel("Founded Year"));
        panel.add(foundedYearField);

        panel.add(new JLabel(""));
        panel.add(updateCompanyButton);

        return panel;
    }

    private JPanel createStockPanel() {
        JPanel panel = new JPanel(new GridLayout(7, 2, 10, 10));

        stockIdField = new JTextField();
        tickerField = new JTextField();
        exchangeField = new JTextField();
        currentPriceField = new JTextField();
        companyComboBox = new JComboBox<>();

        JButton searchButton = new JButton("Search");
        updateStockButton = new JButton("Update");
        updateStockButton.setEnabled(false);

        searchButton.addActionListener(e -> searchStock());
        updateStockButton.addActionListener(e -> updateStock());

        panel.add(new JLabel("Stock ID"));
        panel.add(stockIdField);

        panel.add(new JLabel(""));
        panel.add(searchButton);

        panel.add(new JLabel("Ticker Symbol"));
        panel.add(tickerField);

        panel.add(new JLabel("Exchange Name"));
        panel.add(exchangeField);

        panel.add(new JLabel("Current Price"));
        panel.add(currentPriceField);

        panel.add(new JLabel("Company"));
        panel.add(companyComboBox);

        panel.add(new JLabel(""));
        panel.add(updateStockButton);

        loadCompanies();

        return panel;
    }

    private void searchInvestor() {
        String sql = "SELECT * FROM Investor WHERE InvestorID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, Integer.parseInt(investorIdField.getText()));

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                firstNameField.setText(rs.getString("FirstName"));
                lastNameField.setText(rs.getString("LastName"));
                emailField.setText(rs.getString("Email"));
                phoneField.setText(rs.getString("Phone"));

                investorIdField.setEditable(false);
                updateInvestorButton.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "Investor not found.");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void updateInvestor() {
        String sql = "UPDATE Investor SET FirstName=?, LastName=?, Email=?, Phone=? WHERE InvestorID=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, firstNameField.getText());
            stmt.setString(2, lastNameField.getText());
            stmt.setString(3, emailField.getText());
            stmt.setString(4, phoneField.getText());
            stmt.setInt(5, Integer.parseInt(investorIdField.getText()));

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Investor updated successfully.");
            clearInvestorFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void searchCompany() {
        String sql = "SELECT * FROM Company WHERE CompanyID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, Integer.parseInt(companyIdField.getText()));

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                companyNameField.setText(rs.getString("CompanyName"));
                industryField.setText(rs.getString("Industry"));
                headquartersField.setText(rs.getString("Headquarters"));
                foundedYearField.setText(String.valueOf(rs.getInt("FoundedYear")));

                companyIdField.setEditable(false);
                updateCompanyButton.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "Company not found.");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void updateCompany() {
        String sql = "UPDATE Company SET CompanyName=?, Industry=?, Headquarters=?, FoundedYear=? WHERE CompanyID=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, companyNameField.getText());
            stmt.setString(2, industryField.getText());
            stmt.setString(3, headquartersField.getText());
            stmt.setInt(4, Integer.parseInt(foundedYearField.getText()));
            stmt.setInt(5, Integer.parseInt(companyIdField.getText()));

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Company updated successfully.");
            clearCompanyFields();
            loadCompanies();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void searchStock() {
        String sql = "SELECT * FROM Stock WHERE StockID = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, Integer.parseInt(stockIdField.getText()));

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                tickerField.setText(rs.getString("TickerSymbol"));
                exchangeField.setText(rs.getString("ExchangeName"));
                currentPriceField.setText(String.valueOf(rs.getDouble("CurrentPrice")));

                int companyId = rs.getInt("CompanyID");
                selectCompanyInComboBox(companyId);

                stockIdField.setEditable(false);
                updateStockButton.setEnabled(true);
            } else {
                JOptionPane.showMessageDialog(this, "Stock not found.");
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void updateStock() {
        CompanyItem company = (CompanyItem) companyComboBox.getSelectedItem();

        if (company == null) {
            JOptionPane.showMessageDialog(this, "Please select a company.");
            return;
        }

        String sql = "UPDATE Stock SET TickerSymbol=?, ExchangeName=?, CurrentPrice=?, CompanyID=? WHERE StockID=?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, tickerField.getText());
            stmt.setString(2, exchangeField.getText());
            stmt.setDouble(3, Double.parseDouble(currentPriceField.getText()));
            stmt.setInt(4, company.getCompanyId());
            stmt.setInt(5, Integer.parseInt(stockIdField.getText()));

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(this, "Stock updated successfully.");
            clearStockFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void loadCompanies() {
        if (companyComboBox == null) {
            return;
        }

        companyComboBox.removeAllItems();

        String sql = "SELECT CompanyID, CompanyName FROM Company ORDER BY CompanyName";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                companyComboBox.addItem(
                        new CompanyItem(
                                rs.getInt("CompanyID"),
                                rs.getString("CompanyName")
                        )
                );
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void selectCompanyInComboBox(int companyId) {
        for (int i = 0; i < companyComboBox.getItemCount(); i++) {
            CompanyItem item = companyComboBox.getItemAt(i);

            if (item.getCompanyId() == companyId) {
                companyComboBox.setSelectedIndex(i);
                break;
            }
        }
    }

    private void clearInvestorFields() {
        investorIdField.setText("");
        firstNameField.setText("");
        lastNameField.setText("");
        emailField.setText("");
        phoneField.setText("");
        investorIdField.setEditable(true);
        updateInvestorButton.setEnabled(false);
    }

    private void clearCompanyFields() {
        companyIdField.setText("");
        companyNameField.setText("");
        industryField.setText("");
        headquartersField.setText("");
        foundedYearField.setText("");
        companyIdField.setEditable(true);
        updateCompanyButton.setEnabled(false);
    }

    private void clearStockFields() {
        stockIdField.setText("");
        tickerField.setText("");
        exchangeField.setText("");
        currentPriceField.setText("");
        stockIdField.setEditable(true);
        updateStockButton.setEnabled(false);
    }

    private static class CompanyItem {

        private int companyId;
        private String companyName;

        public CompanyItem(int companyId, String companyName) {
            this.companyId = companyId;
            this.companyName = companyName;
        }

        public int getCompanyId() {
            return companyId;
        }

        @Override
        public String toString() {
            return companyName;
        }
    }
}