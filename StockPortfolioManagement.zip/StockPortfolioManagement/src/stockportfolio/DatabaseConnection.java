package stockportfolio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Manages the database connection for the application.
 */
public class DatabaseConnection {

    private static final String URL =
            "jdbc:mysql://localhost:3306/StockPortfolioDB";

    private static final String USER =
            "root";

    private static final String PASSWORD =
            "Clouddancer@123";

    /**
     * Returns a new database connection.
     *
     * @return a Connection object connected to the database
     * @throws SQLException if the database connection fails
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}