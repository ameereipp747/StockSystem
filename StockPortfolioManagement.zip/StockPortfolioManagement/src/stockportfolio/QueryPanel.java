package stockportfolio;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class QueryPanel extends JPanel {

    private JComboBox<InvestorItem> investorComboBox;
    private JComboBox<String> tradeTypeComboBox;
    private JComboBox<String> sortComboBox;
    private JTable transactionTable;
    private JLabel transactionCountLabel;

    private JComboBox<String> industryComboBox;
    private JComboBox<String> topNComboBox;
    private JTable volumeTable;
    private JLabel volumeCountLabel;

    public QueryPanel() {
        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab("Transactions by Investor", createTransactionQueryPanel());
        tabs.addTab("Top Stocks by Volume", createVolumeQueryPanel());

        tabs.addChangeListener(e -> {
            loadInvestors();
            loadIndustries();
        });

        add(tabs, BorderLayout.CENTER);
    }

    private JPanel createTransactionQueryPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel filterPanel = new JPanel(new FlowLayout());

        investorComboBox = new JComboBox<>();
        tradeTypeComboBox = new JComboBox<>(new String[]{"All", "BUY", "SELL"});
        sortComboBox = new JComboBox<>(new String[]{
                "Date newest first",
                "Date oldest first",
                "Quantity high to low"
        });

        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(e -> runTransactionQuery());

        filterPanel.add(new JLabel("Investor:"));
        filterPanel.add(investorComboBox);

        filterPanel.add(new JLabel("Trade Type:"));
        filterPanel.add(tradeTypeComboBox);

        filterPanel.add(new JLabel("Sort:"));
        filterPanel.add(sortComboBox);

        filterPanel.add(searchButton);

        transactionTable = new JTable();
        transactionCountLabel = new JLabel("Rows: 0");

        panel.add(filterPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(transactionTable), BorderLayout.CENTER);
        panel.add(transactionCountLabel, BorderLayout.SOUTH);

        loadInvestors();

        return panel;
    }

    private JPanel createVolumeQueryPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel filterPanel = new JPanel(new FlowLayout());

        industryComboBox = new JComboBox<>();
        topNComboBox = new JComboBox<>(new String[]{"5", "15", "25", "All"});

        JButton searchButton = new JButton("Search");
        searchButton.addActionListener(e -> runVolumeQuery());

        filterPanel.add(new JLabel("Industry:"));
        filterPanel.add(industryComboBox);

        filterPanel.add(new JLabel("Top N:"));
        filterPanel.add(topNComboBox);

        filterPanel.add(searchButton);

        volumeTable = new JTable();
        volumeCountLabel = new JLabel("Rows: 0");

        panel.add(filterPanel, BorderLayout.NORTH);
        panel.add(new JScrollPane(volumeTable), BorderLayout.CENTER);
        panel.add(volumeCountLabel, BorderLayout.SOUTH);

        loadIndustries();

        return panel;
    }

    private void loadInvestors() {
        if (investorComboBox == null) {
            return;
        }

        investorComboBox.removeAllItems();

        String sql = "SELECT InvestorID, FirstName, LastName FROM Investor ORDER BY LastName";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                investorComboBox.addItem(new InvestorItem(
                        rs.getInt("InvestorID"),
                        rs.getString("FirstName") + " " + rs.getString("LastName")
                ));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void loadIndustries() {
        if (industryComboBox == null) {
            return;
        }

        industryComboBox.removeAllItems();
        industryComboBox.addItem("All");

        String sql = "SELECT DISTINCT Industry FROM Company ORDER BY Industry";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                industryComboBox.addItem(rs.getString("Industry"));
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void runTransactionQuery() {
        InvestorItem investor = (InvestorItem) investorComboBox.getSelectedItem();

        if (investor == null) {
            JOptionPane.showMessageDialog(this, "Please select an investor.");
            return;
        }

        String tradeType = (String) tradeTypeComboBox.getSelectedItem();
        String sort = (String) sortComboBox.getSelectedItem();

        String orderBy;

        if ("Date oldest first".equals(sort)) {
            orderBy = "t.TradeDate ASC";
        } else if ("Quantity high to low".equals(sort)) {
            orderBy = "t.Quantity DESC";
        } else {
            orderBy = "t.TradeDate DESC";
        }

        String sql =
                "SELECT t.TradeDate, t.TradeType, s.TickerSymbol, " +
                "c.CompanyName, c.Industry, t.Quantity, t.PricePerShare " +
                "FROM Investor i " +
                "JOIN BrokerageAccount a ON i.InvestorID = a.InvestorID " +
                "JOIN TradeTransaction t ON a.AccountID = t.AccountID " +
                "JOIN Stock s ON t.StockID = s.StockID " +
                "JOIN Company c ON s.CompanyID = c.CompanyID " +
                "WHERE i.InvestorID = ? ";

        if (!"All".equals(tradeType)) {
            sql += "AND t.TradeType = ? ";
        }

        sql += "ORDER BY " + orderBy;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, investor.getInvestorId());

            if (!"All".equals(tradeType)) {
                stmt.setString(2, tradeType);
            }

            ResultSet rs = stmt.executeQuery();

            DefaultTableModel model = new DefaultTableModel();

            model.addColumn("Trade Date");
            model.addColumn("Trade Type");
            model.addColumn("Ticker Symbol");
            model.addColumn("Company Name");
            model.addColumn("Industry");
            model.addColumn("Quantity");
            model.addColumn("Price Per Share");

            int count = 0;

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getDate("TradeDate"),
                        rs.getString("TradeType"),
                        rs.getString("TickerSymbol"),
                        rs.getString("CompanyName"),
                        rs.getString("Industry"),
                        rs.getInt("Quantity"),
                        rs.getDouble("PricePerShare")
                });

                count++;
            }

            transactionTable.setModel(model);
            transactionCountLabel.setText("Rows: " + count);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private void runVolumeQuery() {
        String industry = (String) industryComboBox.getSelectedItem();
        String topN = (String) topNComboBox.getSelectedItem();

        String sql =
                "SELECT s.TickerSymbol, c.CompanyName, c.Industry, " +
                "SUM(t.Quantity) AS TotalSharesTraded, " +
                "COUNT(t.TransactionID) AS NumberOfTransactions " +
                "FROM Stock s " +
                "JOIN TradeTransaction t ON s.StockID = t.StockID " +
                "JOIN Company c ON s.CompanyID = c.CompanyID ";

        if (!"All".equals(industry)) {
            sql += "WHERE c.Industry = ? ";
        }

        sql +=
                "GROUP BY s.StockID, s.TickerSymbol, c.CompanyName, c.Industry " +
                "ORDER BY TotalSharesTraded DESC ";

        if (!"All".equals(topN)) {
            sql += "LIMIT ?";
        }

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            int parameterIndex = 1;

            if (!"All".equals(industry)) {
                stmt.setString(parameterIndex, industry);
                parameterIndex++;
            }

            if (!"All".equals(topN)) {
                stmt.setInt(parameterIndex, Integer.parseInt(topN));
            }

            ResultSet rs = stmt.executeQuery();

            DefaultTableModel model = new DefaultTableModel();

            model.addColumn("Rank");
            model.addColumn("Ticker Symbol");
            model.addColumn("Company Name");
            model.addColumn("Industry");
            model.addColumn("Total Shares Traded");
            model.addColumn("Number of Transactions");

            int rank = 1;
            int count = 0;

            while (rs.next()) {
                model.addRow(new Object[]{
                        rank,
                        rs.getString("TickerSymbol"),
                        rs.getString("CompanyName"),
                        rs.getString("Industry"),
                        rs.getInt("TotalSharesTraded"),
                        rs.getInt("NumberOfTransactions")
                });

                rank++;
                count++;
            }

            volumeTable.setModel(model);
            volumeCountLabel.setText("Rows: " + count);

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
    }

    private static class InvestorItem {

        private int investorId;
        private String investorName;

        public InvestorItem(int investorId, String investorName) {
            this.investorId = investorId;
            this.investorName = investorName;
        }

        public int getInvestorId() {
            return investorId;
        }

        @Override
        public String toString() {
            return investorName;
        }
    }
}