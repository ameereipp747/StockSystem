package stockportfolio;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class InsertionPanel extends JPanel {

    private JTextField investorFirstNameField;
    private JTextField investorLastNameField;
    private JTextField investorEmailField;
    private JTextField investorPhoneField;

    private JTextField companyNameField;
    private JTextField industryField;
    private JTextField headquartersField;
    private JTextField foundedYearField;

    private JTextField tickerField;
    private JTextField exchangeField;
    private JTextField currentPriceField;

    private JComboBox<CompanyItem> companyComboBox;

    public InsertionPanel() {

        setLayout(new BorderLayout());

        JTabbedPane tabs = new JTabbedPane();

        tabs.addTab(
                "Investor",
                createInvestorPanel());

        tabs.addTab(
                "Company",
                createCompanyPanel());

        tabs.addTab(
                "Stock",
                createStockPanel());

        tabs.addChangeListener(
                e -> loadCompanies());

        add(tabs, BorderLayout.CENTER);
    }

    private JPanel createInvestorPanel() {

        JPanel panel =
                new JPanel(
                        new GridLayout(5, 2, 10, 10));

        investorFirstNameField = new JTextField();
        investorLastNameField = new JTextField();
        investorEmailField = new JTextField();
        investorPhoneField = new JTextField();

        JButton insertButton =
                new JButton("Insert Investor");

        insertButton.addActionListener(
                e -> insertInvestor());

        panel.add(new JLabel("First Name"));
        panel.add(investorFirstNameField);

        panel.add(new JLabel("Last Name"));
        panel.add(investorLastNameField);

        panel.add(new JLabel("Email"));
        panel.add(investorEmailField);

        panel.add(new JLabel("Phone"));
        panel.add(investorPhoneField);

        panel.add(new JLabel(""));
        panel.add(insertButton);

        return panel;
    }

    private JPanel createCompanyPanel() {

        JPanel panel =
                new JPanel(
                        new GridLayout(5, 2, 10, 10));

        companyNameField = new JTextField();
        industryField = new JTextField();
        headquartersField = new JTextField();
        foundedYearField = new JTextField();

        JButton insertButton =
                new JButton("Insert Company");

        insertButton.addActionListener(
                e -> insertCompany());

        panel.add(new JLabel("Company Name"));
        panel.add(companyNameField);

        panel.add(new JLabel("Industry"));
        panel.add(industryField);

        panel.add(new JLabel("Headquarters"));
        panel.add(headquartersField);

        panel.add(new JLabel("Founded Year"));
        panel.add(foundedYearField);

        panel.add(new JLabel(""));
        panel.add(insertButton);

        return panel;
    }

    private JPanel createStockPanel() {

        JPanel panel =
                new JPanel(
                        new GridLayout(5, 2, 10, 10));

        tickerField = new JTextField();
        exchangeField = new JTextField();
        currentPriceField = new JTextField();

        companyComboBox =
                new JComboBox<>();

        JButton insertButton =
                new JButton("Insert Stock");

        insertButton.addActionListener(
                e -> insertStock());

        panel.add(new JLabel("Ticker Symbol"));
        panel.add(tickerField);

        panel.add(new JLabel("Exchange Name"));
        panel.add(exchangeField);

        panel.add(new JLabel("Current Price"));
        panel.add(currentPriceField);

        panel.add(new JLabel("Company"));
        panel.add(companyComboBox);

        panel.add(new JLabel(""));
        panel.add(insertButton);

        loadCompanies();

        return panel;
    }

    private void insertInvestor() {

        String firstName =
                investorFirstNameField
                        .getText()
                        .trim();

        String lastName =
                investorLastNameField
                        .getText()
                        .trim();

        String email =
                investorEmailField
                        .getText()
                        .trim();

        String phone =
                investorPhoneField
                        .getText()
                        .trim();

        if (firstName.isEmpty()
                || lastName.isEmpty()
                || email.isEmpty()) {

            JOptionPane.showMessageDialog(
                    this,
                    "First name, last name, and email are required.");

            return;
        }

        String sql =
                "INSERT INTO Investor "
                        + "(FirstName, LastName, Email, Phone) "
                        + "VALUES (?, ?, ?, ?)";

        try (Connection conn =
                     DatabaseConnection.getConnection();

             PreparedStatement stmt =
                     conn.prepareStatement(sql)) {

            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, email);
            stmt.setString(4, phone);

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Investor inserted successfully.");

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage());
        }
    }

    private void insertCompany() {

        String sql =
                "INSERT INTO Company "
                        + "(CompanyName, Industry, Headquarters, FoundedYear) "
                        + "VALUES (?, ?, ?, ?)";

        try (Connection conn =
                     DatabaseConnection.getConnection();

             PreparedStatement stmt =
                     conn.prepareStatement(sql)) {

            stmt.setString(
                    1,
                    companyNameField.getText());

            stmt.setString(
                    2,
                    industryField.getText());

            stmt.setString(
                    3,
                    headquartersField.getText());

            stmt.setInt(
                    4,
                    Integer.parseInt(
                            foundedYearField.getText()));

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Company inserted successfully.");

            loadCompanies();

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage());
        }
    }

    private void insertStock() {

        CompanyItem company =
                (CompanyItem)
                        companyComboBox
                                .getSelectedItem();

        String sql =
                "INSERT INTO Stock "
                        + "(TickerSymbol, ExchangeName, CurrentPrice, CompanyID) "
                        + "VALUES (?, ?, ?, ?)";

        try (Connection conn =
                     DatabaseConnection.getConnection();

             PreparedStatement stmt =
                     conn.prepareStatement(sql)) {

            stmt.setString(
                    1,
                    tickerField.getText());

            stmt.setString(
                    2,
                    exchangeField.getText());

            stmt.setDouble(
                    3,
                    Double.parseDouble(
                            currentPriceField.getText()));

            stmt.setInt(
                    4,
                    company.getCompanyId());

            stmt.executeUpdate();

            JOptionPane.showMessageDialog(
                    this,
                    "Stock inserted successfully.");

        } catch (Exception ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage());
        }
    }

    private void loadCompanies() {

        if (companyComboBox == null) {
            return;
        }

        companyComboBox.removeAllItems();

        String sql =
                "SELECT CompanyID, CompanyName "
                        + "FROM Company "
                        + "ORDER BY CompanyName";

        try (Connection conn =
                     DatabaseConnection.getConnection();

             PreparedStatement stmt =
                     conn.prepareStatement(sql);

             ResultSet rs =
                     stmt.executeQuery()) {

            while (rs.next()) {

                companyComboBox.addItem(
                        new CompanyItem(
                                rs.getInt("CompanyID"),
                                rs.getString("CompanyName")));
            }

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    ex.getMessage());
        }
    }

    private static class CompanyItem {

        private int companyId;
        private String companyName;

        public CompanyItem(
                int companyId,
                String companyName) {

            this.companyId = companyId;
            this.companyName = companyName;
        }

        public int getCompanyId() {
            return companyId;
        }

        @Override
        public String toString() {
            return companyName;
        }
    }
}