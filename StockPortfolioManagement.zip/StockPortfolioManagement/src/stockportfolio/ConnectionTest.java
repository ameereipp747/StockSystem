package stockportfolio;

import java.sql.Connection;

public class ConnectionTest {

    public static void main(String[] args) {

        try {

            Connection conn =
                    DatabaseConnection.getConnection();

            if (conn != null) {

                System.out.println(
                        "Connection successful!");

                conn.close();
            }

        } catch (Exception e) {

            System.out.println(
                    "Connection failed!");

            e.printStackTrace();
        }
    }
}